const DEFAULT_BLOCKLIST = [
  "goddamn", "god damn", "jesus christ", "jesus", "christ", 
  "damn", "hell", "fuck", "shit", "bitch", "asshole", 
  "motherfucker", "bastard"
];

document.addEventListener('DOMContentLoaded', async () => {
  const wordListEl = document.getElementById('wordList');
  const newWordInput = document.getElementById('newWord');
  const addBtn = document.getElementById('addBtn');
  const hideCcToggle = document.getElementById('hideCcToggle');
  const blurToggle = document.getElementById('blurToggle');
  const masterToggle = document.getElementById('masterToggle');

  // Load existing words and toggle state
  let { blocklist = DEFAULT_BLOCKLIST, disabledWords = [], hideCC = true, enableBlur = true, extensionEnabled = true } = await chrome.storage.local.get(['blocklist', 'disabledWords', 'hideCC', 'enableBlur', 'extensionEnabled']);
  
  masterToggle.checked = extensionEnabled;
  hideCcToggle.checked = hideCC;
  blurToggle.checked = enableBlur;
  
  masterToggle.addEventListener('change', async () => {
    await chrome.storage.local.set({ extensionEnabled: masterToggle.checked });
  });

  hideCcToggle.addEventListener('change', async () => {
    await chrome.storage.local.set({ hideCC: hideCcToggle.checked });
  });

  blurToggle.addEventListener('change', async () => {
    await chrome.storage.local.set({ enableBlur: blurToggle.checked });
  });
  
  function obfuscate(phrase) {
    return phrase.split(' ').map(word => {
      if (word.length <= 2) return word;
      return word[0] + '*'.repeat(word.length - 2) + word[word.length - 1];
    }).join(' ');
  }

  function renderList() {
    wordListEl.innerHTML = '';
    blocklist.forEach((word, index) => {
      const li = document.createElement('li');
      
      const textSpan = document.createElement('span');
      textSpan.textContent = obfuscate(word);
      textSpan.className = 'word-text';
      
      const isDisabled = disabledWords.includes(word);
      if (isDisabled) {
        textSpan.style.textDecoration = 'line-through';
        textSpan.style.opacity = '0.5';
      }
      
      const btnGroup = document.createElement('div');
      btnGroup.className = 'btn-group';
      
      const toggleLabel = document.createElement('label');
      toggleLabel.className = 'toggle-switch small-switch';
      
      const toggleInput = document.createElement('input');
      toggleInput.type = 'checkbox';
      toggleInput.checked = !isDisabled;
      
      const toggleSlider = document.createElement('span');
      toggleSlider.className = 'slider';
      
      toggleLabel.appendChild(toggleInput);
      toggleLabel.appendChild(toggleSlider);
      
      toggleInput.addEventListener('change', async () => {
        const wordIsNowDisabled = !toggleInput.checked;
        if (wordIsNowDisabled) {
          disabledWords.push(word);
        } else {
          disabledWords = disabledWords.filter(w => w !== word);
        }
        await chrome.storage.local.set({ disabledWords });
        renderList();
      });
      
      const revealBtn = document.createElement('button');
      revealBtn.className = 'reveal-btn';
      revealBtn.innerHTML = `<svg viewBox="0 0 24 24" width="14" height="14" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>`;
      revealBtn.title = 'Reveal Word';
      revealBtn.onclick = () => {
        textSpan.textContent = word;
        setTimeout(() => { textSpan.textContent = obfuscate(word); }, 2000);
      };
      
      const delBtn = document.createElement('button');
      delBtn.className = 'delete-btn';
      delBtn.innerHTML = `<svg viewBox="0 0 24 24" width="14" height="14" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg>`;
      delBtn.title = 'Delete Word';
      delBtn.onclick = async () => {
        blocklist.splice(index, 1);
        disabledWords = disabledWords.filter(w => w !== word);
        await chrome.storage.local.set({ blocklist, disabledWords });
        renderList();
      };
      
      btnGroup.appendChild(toggleLabel);
      btnGroup.appendChild(revealBtn);
      btnGroup.appendChild(delBtn);
      
      li.appendChild(textSpan);
      li.appendChild(btnGroup);
      wordListEl.appendChild(li);
    });
  }
  
  renderList();

  // Add new word
  async function addWord() {
    const word = newWordInput.value.trim().toLowerCase();
    if (word && !blocklist.includes(word)) {
      blocklist.push(word);
      await chrome.storage.local.set({ blocklist });
      newWordInput.value = '';
      renderList();
    }
  }

  addBtn.addEventListener('click', addWord);
  newWordInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') addWord();
  });
});
